#building  a list without list() constructor
mylist = ["apple", "banana", "cherry", "mango"]

#definition a string and assigning value
a = "EDGE Students are from different Institutions not only from MBSTU"

#print string letter by letter
print("\n1) This is String Split: Letter by letter up to index 4\n")

#start a loop to print the first 4 items of the string
for i in a[:5]:
    print(i)

#How a string becomes list after spliting
print("\n2) After String Split, now it a list. See all")

#spliting by whitespace
b = a.split(" ")

#priting newly built list (from string) - word by word not letter by letter
for w in b:
    print(w)

#
print("\n3) Printing index 2 to 4 in uppercase")

#printing newly built list within the index starting from 2 to 4 in uppercase
c = b[2:5]
for sw in c:
    print(sw.upper())