
mylist = ["apple", "banana", "cherry", "mango"]

a = "EDGE Students are from different Institutions not only from MBSTU"

print("\n1) This is String Split: Letter by letter up to index 4\n")
for i in a[:5]:
	print(i)

print("\n2) After String Split, now it a list. See all")

b = a.split(" ")
for w in b:
	print(w)

print("\n3) Printing index 2 to 4 in uppercase")

c = b[2:5]
for sw in c:
	print(sw.upper())
